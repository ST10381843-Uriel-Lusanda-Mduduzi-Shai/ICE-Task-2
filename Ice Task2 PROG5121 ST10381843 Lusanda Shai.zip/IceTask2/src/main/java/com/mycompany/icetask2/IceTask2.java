package com.mycompany.icetask2;
import java.util.Scanner;

public class IceTask2 {

    public static void main(String[] args) {
        String Name;
        String Surname;
        int Age;
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Please enter your name : ");
        Name = scan.next();
        System.out.println("Please enter your surname : ");
        Surname = scan.next();
        System.out.println("Please enter your age : ");
        Age = scan.nextInt();
        
        CheckIdentity();
        if (Name.equals("Jack") && Surname.equals("Khoza") && Age == 25){
            System.out.println("This is Jack");
        }else{
            System.out.println("This is not Jack");
        }
    }
    
    static void CheckIdentity(){
        
        String Name;
        String Surname;
        int Age;
        
        Name = "Jack";
        Surname = "Khoza";
        Age = 25;
        
    }
 
}


